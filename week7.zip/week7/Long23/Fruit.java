/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.myproject.week7.Long23;

/**
 *
 * @author LENOVO
 */
public class Fruit {
    public int fruitId;
    public String fruitName;
    public int Price;
    public int Quantity;
    public String Origin;

    public Fruit(int fruitId, String fruitName, int Price, int Quantity, String Origin) {
        this.fruitId = fruitId;
        this.fruitName = fruitName;
        this.Price = Price;
        this.Quantity = Quantity;
        this.Origin = Origin;
    }

    public int getFruitId() {
        return fruitId;
    }

    public String getFruitName() {
        return fruitName;
    }

    public int getPrice() {
        return Price;
    }

    public int getQuantity() {
        return Quantity;
    }

    public String getOrigin() {
        return Origin;
    }
    public void reduceQuantity(int amount) {
        this.Quantity -= amount;
    }
    

    @Override
    public String toString() {
        return "Fruit{" + "Fruit's ID = " + fruitId + ", Fruit's Name = " + fruitName + ", Price = " + Price + ", Quantity = " + Quantity + ", Origin = " + Origin + '}';
    }   
    
}
