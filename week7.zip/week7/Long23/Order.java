/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.myproject.week7.Long23;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author LENOVO
 */
public class Order {
        String customerName;
        List<Fruit> items;
        List<Integer> quantities;
        
        public Order (String customeName) {
            this.customerName = customeName;
            this.items = new ArrayList<>();
            this.quantities = new ArrayList<>();
        }
        
        public void addItem(Fruit f, int quantity) {
            items.add(f);
            quantities.add(quantity);
        }
        
        public double getTotal() {
            double total = 0;
            for (int i = 0; i < items.size(); i++) {
                total += items.get(i).Price * quantities.get(i);
            }
            return total;
        }
        
        public void printOrder() {
            System.out.println("Customer:"+customerName);
            System.out.println("Product | Quantity | Price | Amount");
            for (int i = 0; i < items.size();i++) {
                Fruit f = items.get(i);
                int quantity = quantities.get(i);
                System.out.println(f.fruitName + " | " + quantity + " | "
                 + f.Price + "$ | " + (f.Price * quantity) + "$") ;
            } System.out.println("Total : " + getTotal() + "$\n");       
            }
        }
