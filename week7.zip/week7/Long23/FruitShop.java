/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.myproject.week7.Long23;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author LENOVO
 */
public class FruitShop {
    private List<Fruit> fruit = new ArrayList<>();
    private Hashtable<String, Order> order = new Hashtable<>();
    private Scanner scanner = new Scanner(System.in);
    
    
    public void run() {
     while (true) {   
         System.out.println("\nFRUIT SHOP SYSTEM");
            System.out.println("1. Create Fruit");
            System.out.println("2. View orders");
            System.out.println("3. Shopping (for buyer)");
            System.out.println("4. Exit");
            System.out.print("Please choose : ");
            
            String choice = scanner.nextLine();
            
            switch (choice) {
             case "1":
                   createFruit();
                   break;
             case "2":
                  viewOrder();
                  break;
             case "3":
                  shopping();
                  break;
             case "4":
                 System.out.println("Exiting the shopping...");
                 scanner.close();
                 return;
             default:
                 System.out.println("Invalid choice! Try again");
            }
         }
    }
    
    private void createFruit() {
        while (true) {
            System.out.print("Enter Fruit's ID: ");
            int id = Integer.parseInt(scanner.nextLine());
            System.out.print("Enter Fruit's Name: ");
            String name = scanner.nextLine();
            System.out.print("Enter Price: ");
            int price = Integer.parseInt(scanner.nextLine());
            System.out.print("Enter Quantity: ");
            int quant = Integer.parseInt(scanner.nextLine());
            System.out.print("Enter Origin: ");
            String origin = scanner.nextLine();
            Fruit f = new Fruit(id, name, price, quant, origin);
            fruit.add(f);
            System.out.println("Do you want to continue (Y/N)? ");
            if (!scanner.nextLine().equalsIgnoreCase("Y"))
            break;
        }
    }
    
    private void viewOrder() {
        if (order.isEmpty()) {
            System.out.println("No order found. ");
        } else {
            for (Order o : order.values()) {
                o.printOrder();
            }
        }
    }
    private void shopping() {
        if (fruit.isEmpty()) {
            System.out.println("No fruits for sale.");
            return;
        }
        System.out.println("Input your name: ");
        String customerName = scanner.nextLine();
        Order currentOrder = new Order(customerName);
        while (true) {
            System.out.println("\nList of Fruits: ");
            for (Fruit f : fruit ) {
                System.out.println(f);
        }
            System.out.println("Select Fruit to buy: ");
            int id = Integer.parseInt(scanner.nextLine());
            
            Fruit selectedFruit = null;
            for (Fruit f : fruit) {
                if (f.getFruitId() == id) {
                    selectedFruit = f;
                    break;
                }
            }
            if (selectedFruit == null) {
                System.out.println("Invalid! Try again");
                continue;
            }
            System.out.println("You selected: "+selectedFruit.getFruitName());
            System.out.println("Input quantity: ");
            int quant = Integer.parseInt(scanner.nextLine());
            
            if (quant > selectedFruit.getQuantity()) {
                System.out.println("Not enough stock!");
                continue;
            }
            
            System.out.println("Do you want to order now (Y/N)?");
            if (scanner.nextLine().equalsIgnoreCase("Y")) {
                currentOrder.addItem(selectedFruit, quant);
                selectedFruit.reduceQuantity(quant);
    }
            System.out.println("Do you want to continue shopping (Y/N)?");
            if (!scanner.nextLine().equalsIgnoreCase("Y")) {
                break;
            }
        }
            
            if(!currentOrder.items.isEmpty()) {
                order.put(customerName, currentOrder);
                System.out.println("Order placed successfully!");
            } else {          
            System.out.println("No items were purchased. Cancel the order!");
        }
    }
}
