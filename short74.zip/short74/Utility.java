/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package week2.short74;

/**
 *
 * @author LENOVO
 */
import java.util.Scanner;

public class Utility {

    public static double getDoubleInput(Scanner scanner, String prompt) {
        while (true) {
            try {
                System.out.print(prompt);
                return Double.parseDouble(scanner.next());
            } catch (NumberFormatException e) {
                System.out.println("Value of matrix is digit.");
            }
        }
    }

    public static int getIntegerInput(Scanner scanner, String prompt) {
        while (true) {
            try {
                System.out.print(prompt);
                return Integer.parseInt(scanner.next());
            } catch (NumberFormatException e) {
                System.out.println("Please input a valid integer.");
            }
        }
    }
}
