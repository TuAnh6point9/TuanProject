/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.myproject.week6.short56;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
/**
 *
 * @author LENOVO
 */
public class WorkerManagement {
    private List<Worker> workers = new ArrayList<>();
    private static Scanner scanner = new Scanner(System.in);

    public void displayMenu() {
        while (true) {
            System.out.println("======== Worker Management ========");
            System.out.println("1. Add Worker");
            System.out.println("2. Up salary");
            System.out.println("3. Down salary");
            System.out.println("4. Display Information salary");
            System.out.println("5. Exit");
            System.out.print("Enter your choice: ");

            int choice = Integer.parseInt(scanner.nextLine());

            switch (choice) {
                case 1:
                    addWorker();
                    break;
                case 2:
                    changeUpSalary("UP");
                    break;
                case 3:
                    changeDownSalary("DOWN");
                    break;
                case 4:
                    getInformationSalary();
                    break;
                case 5:
                    System.out.println("Exiting program...");
                    return;
                default:
                    System.out.println("Invalid choice, please enter a number between 1-5.");
            }
        }
    }

    private void addWorker() {
        System.out.println("--------- Add Worker ---------");
        System.out.print("Enter Code: ");
        String code = scanner.nextLine();
        System.out.print("Enter Name: ");
        String name = scanner.nextLine();
        System.out.print("Enter Age: ");
        int age = Integer.parseInt(scanner.nextLine());
        System.out.print("Enter Salary: ");
        double salary = Double.parseDouble(scanner.nextLine());
        System.out.print("Enter work location: ");
        String workLocation = scanner.nextLine();

        Worker worker = new Worker(code, name, age, salary, workLocation);
        workers.add(worker);
        System.out.println("Worker added successfully!");
    }
    
    public class ChangeUpSalary extends Salary {
        public ChangeUpSalary(double salary, String date) {
            super(salary, "UP", date);
        }
    }

    public class ChangeDownSalary extends Salary {
        public ChangeDownSalary(double salary, String date) {
            super(salary, "DOWN", date);
        }
    }

    public void changeUpSalary(String code) {
        System.out.println("------- Up/Down Salary --------");
        System.out.print("Enter Code: ");
        String inputCode = scanner.nextLine();

        System.out.print("Enter Salary: ");
        double amount = Double.parseDouble(scanner.nextLine());

        Worker w = null;
        for (Worker worker : workers) {
            if (worker.getCode().equals(inputCode)) {
                w = worker;
                break;
            }
        }
        if (w == null) {
            System.out.println("Worker not found!");
            return;
        }
        String date = java.time.LocalDate.now().toString();
        Salary s = new ChangeUpSalary(amount, date);
        w.addSalary(s); 
        System.out.println("Salary increased successfully!");
    }
    
    public void changeDownSalary(String code) {
        System.out.println("------- Up/Down Salary --------");
        System.out.print("Enter Code: ");
        String inputCode = scanner.nextLine();

        System.out.print("Enter Salary: ");
        double amount = Double.parseDouble(scanner.nextLine());

        Worker w = null;
        for (Worker worker : workers) {
            if (worker.getCode().equals(inputCode)) {
                w = worker;
                break;
            }
        }
        if (w == null) {
            System.out.println("Worker not found!");
            return;
        }
         String date = java.time.LocalDate.now().toString();
         Salary s = new ChangeDownSalary(amount, date); 
         w.addSalary(s);
    System.out.println("Salary decreased successfully!");
    }
    
    private void getInformationSalary() {
        System.out.println("--------------------Display Information Salary--------------------");
        System.out.println("Code   Name   Age   Salary   Status   Date");

        if (workers.isEmpty()) {
            System.out.println("No salary records found.");
            return;
        }

        for (Worker w : workers) {
            for (Salary s : w.getSalaryHistory()) {
                System.out.printf("%-6s %-6s %-4d %-8.2f %-6s %s\n",
                        w.getCode(), w.getName(), w.getAge(), s.getSalary(), s.getStatus(), s.getDate());
            }
        }
    }

    private Worker findWorkerByCode(String code) {
        for (Worker worker : workers) {
            if (worker.getCode().equals(code)) {
                return worker;
            }
        }
        return null;
    }

    public static void main(String[] args) {
        WorkerManagement wm = new WorkerManagement();
        wm.displayMenu();
    }
}
