/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.myproject.week6.short56;

/**
 *
 * @author LENOVO
 */
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
public class Salary {
    
    private double salary;
    private String Status;
    private String date;

    public Salary(double salary, String Status, String date) {
        this.salary = salary;
        this.Status = Status;
        this.date = LocalDate.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
    }

    public double getSalary() {
        return salary;
    }

    public String getStatus() {
        return Status;
    }

    public String getDate() {
        return date;
    }
}