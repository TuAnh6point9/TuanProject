/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.myproject.week6.short56;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author LENOVO
 */
public class Worker {
    private String Code;
    private String Name;
    private int Age;
    private double salary;
    private String workLocation;
    private List<Salary> salaryHistory;

    public Worker(String Code, String Name, int Age, double salary, String workLocation) {
        this.Code = Code;
        this.Name = Name;
        this.Age = Age;
        this.salary = salary;
        this.workLocation = workLocation;
        this.salaryHistory = new ArrayList<>();
        

        String date = java.time.LocalDateTime.now().toString();
        this.salaryHistory.add(new Salary(salary, "UP", date));
         
    }
   
    

    public String getCode() {
        return Code;
    }

    public String getName() {
        return Name;
    }

    public int getAge() {
        return Age;
    }

    public String getWorkLocation() {
        return workLocation;
    }

    public double getSalary() {
        return salary;
    }

    public List<Salary> getSalaryHistory() {
        return salaryHistory;
    }


    public void addSalary(Salary s) {
       if (s.getStatus().equalsIgnoreCase("UP")) {
           this.salary += s.getSalary();
       }
       if (s.getStatus().equalsIgnoreCase("DOWN")) {
           this.salary -= s.getSalary();
       }
       salaryHistory.add(s);
       }
    }
   
