/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.myproject.week6.short54;

/**
 *
 * @author LENOVO
 */
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.regex.Pattern;

class Contact {
    private int id;
    private String fullName;
    private String firstName;
    private String lastName;
    private String group;
    private String address;
    private String phone;

    public Contact(int id, String fullName, String group, String address, String phone) {
        this.id = id;
        this.fullName = fullName;
        String[] names = fullName.split("\\s+", 2);
        this.firstName = names[0];
        this.lastName = names.length > 1 ? names[1] : "";
        this.group = group;
        this.address = address;
        this.phone = phone;
    }

    public int getId() { return id; }
    public String getFullName() { return fullName; }
    public String getFirstName() { return firstName; }
    public String getLastName() { return lastName; }
    public String getGroup() { return group; }
    public String getAddress() { return address; }
    public String getPhone() { return phone; }
}

class ContactManager {
    private List<Contact> contacts;
    private int nextId;

    public ContactManager() {
        contacts = new ArrayList<>();
        nextId = 1;
    }

    private boolean isValidPhone(String phone) {
        String[] patterns = {
            "^\\d{10}$",                    
            "^\\d{3}-\\d{3}-\\d{4}$",      
            "^\\d{3}-\\d{3}-\\d{4}\\sx\\d+$",  
            "^\\d{3}-\\d{3}-\\d{4}\\sext\\d+$", 
            "^\\d{3}\\.\\d{3}\\.\\d{4}$",  
            "^\\d{3}\\s\\d{3}\\s\\d{4}$"   
        };
        
        for (String pattern : patterns) {
            if (Pattern.matches(pattern, phone)) {
                return true;
            }
        }
        return false;
    }

    public boolean addContact(String fullName, String group, String address, String phone) {
        if (!isValidPhone(phone)) {
            System.out.println("Invalid phone format. Please use one of the following:");
            System.out.println("> 1234567890");
            System.out.println("> 123-456-7890");
            System.out.println("> 123-456-7890 x1234");
            System.out.println("> 123-456-7890 ext1234");
            System.out.println("> 123.456.7890");
            System.out.println("> 123 456 7890");
            return false;
        }
        Contact contact = new Contact(nextId, fullName, group, address, phone);
        contacts.add(contact);
        nextId++;
        return true;
    }

    public boolean addContact(Contact contact) {
        if (!isValidPhone(contact.getPhone())) {
            return false;
        }
        contacts.add(contact);
        nextId++;
        return true;
    }

    public void displayAll() {
        if (contacts.isEmpty()) {
            System.out.println("No contacts available.");
            return;
        }
        System.out.println("--------------------------------- Display all Contact ----------------------------");
        System.out.printf("%-5s%-20s%-15s%-15s%-10s%-15s%-15s%n", 
            "ID", "Name", "First Name", "Last Name", "Group", "Address", "Phone");
        for (Contact c : contacts) {
            System.out.printf("%-5d%-20s%-15s%-15s%-10s%-15s%-15s%n",
                c.getId(), c.getFullName(), c.getFirstName(), c.getLastName(),
                c.getGroup(), c.getAddress(), c.getPhone());
        }
    }

    public boolean deleteContact(int id) {
        for (int i = 0; i < contacts.size(); i++) {
            if (contacts.get(i).getId() == id) {
                contacts.remove(i);
                return true;
            }
        }
        return false;
    }
}

public class ContactManagement {
    private static Scanner scanner = new Scanner(System.in);
    private static ContactManager manager = new ContactManager();
    
    public static void main(String[] args) {
        while (true) {
            displayMenu();
            String choice = scanner.nextLine().trim(); 
            
            switch (choice) {
                case "1": 
                    addContact();
                    break; 
                case "2":
                    manager.displayAll();
                    break;
                case "3":
                    deleteContact();
                    break;
                case "4":
                    System.out.println("See you next time");
                    return;
                default:
                    System.out.println("Invalid option. Please choose 1 to 4");
            }
        }
    }
    
    private static void displayMenu() {
        System.out.println("======= Contact Program =======");
        System.out.println("1. Add a Contact");
        System.out.println("2. Display all Contact");
        System.out.println("3. Delete a Contact");
        System.out.println("4. Exit");
        System.out.print("Please choose one option: ");
    }

    private static void addContact() {
        System.out.println("======= Add a Contact ========");
        System.out.print("Enter Full Name: ");
        String fullName = scanner.nextLine();
        
        System.out.print("Enter Group: ");
        String group = scanner.nextLine();
        
        System.out.print("Enter Address: ");
        String address = scanner.nextLine();
        
        System.out.print("Enter Phone: ");
        String phone = scanner.nextLine();
        
        if (manager.addContact(fullName, group, address, phone)) {
            System.out.println("Added Successfully");
        }
    }

    private static void deleteContact() {
        System.out.println("-------Delete a Contact-------");
        System.out.print("Enter ID: "); // Fixed typo "println" to "print"
        String input = scanner.nextLine();
        
        try {
            int id = Integer.parseInt(input);
            if (manager.deleteContact(id)) {
                System.out.println("Deleted Successfully");
            } else { 
                System.out.println("No contact found");
            }
        } catch (NumberFormatException e) {
            System.out.println("ID must be a digit");
        }
    }
}