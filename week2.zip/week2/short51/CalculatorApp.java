/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package week2.short51;

/**
 *
 * @author LENOVO
 */
import java.util.Scanner;

public class CalculatorApp {
    
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        BMICalculator bmicalculator = new BMICalculator();
        NormalCalculator normalcalculator = new NormalCalculator();
        int choice;
        
        do {
            displayMenu();
            choice = Utility.getIntegerInput(scanner, "Please input an option: ");
            
            switch (choice) {
                case 1:
                    normalcalculator.performNormalCalculator(scanner);
                case 2:
                     bmicalculator.performBMICalculator(scanner);
                case 3:
                    System.out.println("Exiting the program...");
                    break;
                default: 
                    System.out.println("Invalid choice. Try again ");
                }
        } while (choice != 3);
        scanner.close();
    }
    
    private static void displayMenu() {
        System.out.println("========= Calculator Program =========");
        System.out.println("1. Normal Calculator");
        System.out.println("2. BMI Calculator");
        System.out.println("3. Exit"); 
    }
    
        
    }
    
    
        
   