/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package week2.short51;

/**
 *
 * @author LENOVO
 */
import java.util.Scanner;

public class NormalCalculator {
    
enum Operator {
    ADD("+"), SUBTRACT("-"), MULTIPLY("*"), DIVIDE("/"), EXPONENT("^"), EQUAL("=");
    
    private final String symbol;
    
    Operator(String symbol) {
        this.symbol = symbol;
    }
    
    public String getSymbol() {
        return symbol;
    }
    
    public static Operator fromString(String operator) {
        for (Operator op : values()) {
            if (op.symbol.equals(operator)) {
                return op;
            }
        }
        return null;
    }
}
    
    public void performNormalCalculator(Scanner scanner) {
        System.out.println("--------Normal Calculator--------");
    
        try { 
             double memory = Utility.getDoubleInput(scanner, "Enter number:");
        
             while (true) {
                 System.out.print("Enter Operator: ");
                 String operatorInput = scanner.next();
                 Operator operator = Operator.fromString(operatorInput);
            
                 if (operator == null) {
                     System.out.println("Please input (+,-,*,/,^,+)");
                     continue;
                }
            
                 if (operator == Operator.EQUAL) {
                     System.out.println("Result: "+ memory);
                     return;
                }
        
                 double nextNumber = Utility.getDoubleInput(scanner, "Enter number: ");
                 memory = calculate(memory, operator, nextNumber);
                 System.out.println("Memory: " + memory);
            }
        } catch (ArithmeticException e) {
                 System.out.println("Error"+ e.getMessage());
        }
    }
    
    private double calculate(double a, Operator operator, double b) {
         switch (operator) {
            case ADD:
                 return a + b;
            case SUBTRACT: 
                 return a - b;
            case MULTIPLY:
                 return a * b;
            case DIVIDE:
                 if ( b == 0 ) throw new ArithmeticException("Cannot divide by zero");
                 return a / b;
            case EXPONENT:
                 return Math.pow(a,b);
            default:
                 throw new IllegalArgumentException("Invalid operator");
            } 
        }
    }