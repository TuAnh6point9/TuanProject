/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package week2.short51;

/**
 *
 * @author LENOVO
 */
import java.util.Scanner;

public class BMICalculator {
    
    enum BMIStatus {
        UNDER_STANDARD, STANDARD, OVERWEIGHT, ULTRA_FAT, SUPER_ULTRA_FAT
    }
    
    public void performBMICalculator(Scanner scanner) {
        
            System.out.println("--------BMI Calculator--------");
            
        try {
            double weight = Utility.getDoubleInput(scanner, "Enter Weight(kg): ");
            double heightCm = Utility.getDoubleInput(scanner, "Enter Height(cm): ");
            double heightM = heightCm / 100;
            
            double bmi = calculateBMI(weight, heightM);
            BMIStatus status = getBMIStatus(bmi);
            
            System.out.printf("BMI Number: %2f\n", bmi);
            System.out.println("BMI status:" + status);
        } catch (NumberFormatException e) {
            System.out.println("Please inter a valid number. ");
        }
    }
    
    private double calculateBMI(double weight, double height) {
        return weight / (height * height);
    }
    
    private BMIStatus getBMIStatus(double bmi) {
        if (bmi < 19) {
             return BMIStatus.UNDER_STANDARD;
        } else if (bmi >= 19 && bmi <= 25) {
            return BMIStatus.STANDARD;
        } else if (bmi > 25 && bmi <= 30) {
            return BMIStatus.OVERWEIGHT;
        } else if (bmi > 30 && bmi <= 40) {
            return BMIStatus.ULTRA_FAT;
        } else  {
            return BMIStatus.SUPER_ULTRA_FAT;
                }
            }
        }

            
        
 