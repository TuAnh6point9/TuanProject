/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package week2.short74;

import java.util.Scanner;



/**
 *
 * @author LENOVO
 */
public class Matrix {

    private final int rows;
    private final int cols;
    private final double[][] data;

    public Matrix(int rows, int cols) {
        this.rows = rows;
        this.cols = cols;
        this.data = new double[rows][cols];
    }

    public static Matrix createMatrix(Scanner scanner, int rows, int cols) {
        Matrix matrix = new Matrix(rows, cols);

        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                matrix.data[i][j] = Utility.getDoubleInput(scanner, "Enter Matrix[" + (i + 1) + "][" + (j + 1) + "]: ");
            }
        }

        return matrix;
    }

    public Matrix additionMatrix(Matrix matrix2) {
        validateSameDimensions(matrix2);

        Matrix result = new Matrix(rows, cols);
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                result.data[i][j] = this.data[i][j] + matrix2.data[i][j];
            }
        }
        return result;
    }

    public Matrix subtractionMatrix(Matrix matrix2) {
        validateSameDimensions(matrix2);

        Matrix result = new Matrix(rows, cols);
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                result.data[i][j] = this.data[i][j] - matrix2.data[i][j];
            }
        }
        return result;
    }

    public Matrix multiplicationMatrix(Matrix matrix2) {
        if (this.cols != matrix2.rows) {
            throw new IllegalArgumentException("Matrix1 columns must match Matrix2 rows for multiplication.");
        }

        Matrix result = new Matrix(this.rows, matrix2.cols);
        for (int i = 0; i < result.rows; i++) {
            for (int j = 0; j < result.cols; j++) {
                for (int k = 0; k < this.cols; k++) {
                    result.data[i][j] += this.data[i][k] * matrix2.data[k][j];
                }
            }
        }
        return result;
    }

    private void validateSameDimensions(Matrix matrix2) {
        if (this.rows != matrix2.rows || this.cols != matrix2.cols) {
            throw new IllegalArgumentException("Matrices dimensions must match for this operation.");
        }
    }

    public void displayFormatted() {
        for (double[] row : data) {
            System.out.print("[");
            for (double value : row) {
                System.out.print((int) value + "]");
            }
            System.out.println();
        }
    }

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
}

