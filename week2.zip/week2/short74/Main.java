/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package week2.short74;

/**
 *
 * @author LENOVO
 */
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int choice;

        do {
            displayMenu();
            choice = Utility.getIntegerInput(scanner, "Please select an option: ");

            switch (choice) {
                case 1:
                    performMatrixOperation(scanner, "addition");
                    break;
                case 2:
                    performMatrixOperation(scanner, "subtraction");
                    break;
                case 3:
                    performMatrixOperation(scanner, "multiplication");
                    break;
                case 4:
                    System.out.println("Exiting program. Goodbye!");
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        } while (choice != 4);

        scanner.close();
    }

    private static void displayMenu() {
        System.out.println("======== Matrix Calculator ========");
        System.out.println("1. Addition of Matrices");
        System.out.println("2. Subtraction of Matrices");
        System.out.println("3. Multiplication of Matrices");
        System.out.println("4. Exit");
    }

    private static void performMatrixOperation(Scanner scanner, String operation) {
        System.out.println("----- " + capitalize(operation) + " -----");

        int rows = Utility.getIntegerInput(scanner, "Enter Row Matrix 1: ");
        int cols = Utility.getIntegerInput(scanner, "Enter Column Matrix 1: ");

        System.out.println("Enter values for Matrix1: ");
        Matrix matrix1 = Matrix.createMatrix(scanner, rows, cols);


        System.out.println("Enter Row Matrix 2: " + rows); 
        int cols2 = Utility.getIntegerInput(scanner, "Enter Column Matrix 2: ");


        System.out.println("Enter values for Matrix2: ");
        Matrix matrix2 = Matrix.createMatrix(scanner, rows, cols2);

        try {
            Matrix result;
            switch (operation) {
                case "addition":
                    result = matrix1.additionMatrix(matrix2);
                    break;
                case "subtraction":
                    result = matrix1.subtractionMatrix(matrix2);
                    break;
                case "multiplication":
                    result = matrix1.multiplicationMatrix(matrix2);
                    break;
                default:
                    throw new IllegalArgumentException("Invalid operation.");
            }


            System.out.println("-------- Result --------");
            matrix1.displayFormatted();
            System.out.println(operation.equals("addition") ? "+" : operation.equals("subtraction") ? "-" : "*");
            matrix2.displayFormatted();
            System.out.println("=");
            result.displayFormatted();

        } catch (IllegalArgumentException e) {
            System.out.println(e.getMessage());
        }
    }

    private static String capitalize(String str) {
        return str.substring(0, 1).toUpperCase() + str.substring(1);
    }
}
