/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.myproject.week4.Long21;

/**
 *
 * @author LENOVO
 */
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class StudentReport {
    public static void generateReport(List<Student> students) {
        if (students.isEmpty()) {
            System.out.println("No student records available.");
            return;
        }

        Map<String, Map<String, Integer>> reportData = new HashMap<>();

        for (Student student : students) {
            String name = student.getStudentName();
            String course = student.getCourseName();

            reportData.putIfAbsent(name, new HashMap<>());
            reportData.get(name).put(course, reportData.get(name).getOrDefault(course, 0) + 1);
        }

        System.out.println("\nSTUDENT REPORT");
        System.out.println("Student Name | Course | Total Courses");

        for (Map.Entry<String, Map<String, Integer>> entry : reportData.entrySet()) {
            String studentName = entry.getKey();
            for (Map.Entry<String, Integer> courseEntry : entry.getValue().entrySet()) {
                System.out.printf("%-12s | %-6s | %d%n", studentName, courseEntry.getKey(), courseEntry.getValue());
            }
        }
    }
}