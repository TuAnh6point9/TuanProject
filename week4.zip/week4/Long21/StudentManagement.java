/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.myproject.week4.Long21;

/**
 *
 * @author LENOVO
 */
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.Collections;
import java.util.Comparator;

public class StudentManagement {
    private final List<Student> students = new ArrayList<>();
    private final Scanner scanner = new Scanner(System.in);

    public void start() {
        while (true) {
            System.out.println("\nWELCOME TO STUDENT MANAGEMENT");
            System.out.println("1. Create");
            System.out.println("2. Find and Sort");
            System.out.println("3. Update/Delete");
            System.out.println("4. Report");
            System.out.println("5. Exit");
            System.out.print("Your choice: ");

            int choice = scanner.nextInt();
            scanner.nextLine(); 

            switch (choice) {
                case 1 -> createStudent();
                case 2 -> findAndSortStudents();
                case 3 -> updateOrDeleteStudent();
                case 4 -> StudentReport.generateReport(students);
                case 5 -> {
                    System.out.println("Exiting program...");
                    return;
                }
                default -> System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private void createStudent() {
        while (true) {
            System.out.print("Enter student ID: ");
            String id = scanner.nextLine();

            System.out.print("Enter student name: ");
            String name = scanner.nextLine();

            System.out.print("Enter semester: ");
            int semester = scanner.nextInt();
            scanner.nextLine();

            System.out.print("Enter course (Java/.Net/C++): ");
            String course = scanner.nextLine();

            if (!course.equalsIgnoreCase("Java") &&
                !course.equalsIgnoreCase(".Net") &&
                !course.equalsIgnoreCase("C++")) {
                System.out.println("Invalid course. Choose Java, .Net, or C++.");
                continue;
            }

            students.add(new Student(id, name, semester, course));

            System.out.print("Do you want to continue adding students? (Y/N): ");
            String response = scanner.nextLine();
            if (response.equalsIgnoreCase("N")) break;
        }
    }

    private void findAndSortStudents() {
        if (students.isEmpty()) {
            System.out.println("No student records available.");
            return;
        }

        System.out.print("Enter student name to search: ");
        String searchName = scanner.nextLine().toLowerCase();

        List<Student> matchedStudents = new ArrayList<>();
        for (Student student : students) {
            if (student.getStudentName().toLowerCase().contains(searchName)) {
                matchedStudents.add(student);
            }
        }

        if (matchedStudents.isEmpty()) {
            System.out.println("No students found with that name.");
            return;
        }

        Collections.sort(matchedStudents, Comparator.comparing(Student::getStudentName));

        System.out.println("\nSearch Results:");
        System.out.println("Student Name | Semester | Course");
        for (Student student : matchedStudents) {
            System.out.printf("%-12s | %-8d | %-6s%n", student.getStudentName(), student.getSemester(), student.getCourseName());
        }
    }

    private void updateOrDeleteStudent() {
        if (students.isEmpty()) {
            System.out.println("No student records available.");
            return;
        }

        System.out.print("Enter student ID to find: ");
        String id = scanner.nextLine();

        Student student = null;
        for (Student s : students) {
            if (s.getId().equals(id)) {
                student = s;
                break;
            }
        }

        if (student == null) {
            System.out.println("Student not found.");
            return;
        }

        System.out.print("Do you want to Update (U) or Delete (D) the student? ");
        String choice = scanner.nextLine();

        if (choice.equalsIgnoreCase("U")) {
            System.out.print("Enter new name (press Enter to keep current): ");
            String newName = scanner.nextLine();
            if (!newName.isEmpty()) student.setStudentName(newName);

            System.out.print("Enter new semester (press Enter to keep current): ");
            String semesterInput = scanner.nextLine();
            if (!semesterInput.isEmpty()) student.setSemester(Integer.parseInt(semesterInput));

            System.out.print("Enter new course (Java/.Net/C++, press Enter to keep current): ");
            String newCourse = scanner.nextLine();
            if (!newCourse.isEmpty() && (newCourse.equalsIgnoreCase("Java") || newCourse.equalsIgnoreCase(".Net") || newCourse.equalsIgnoreCase("C++"))) {
                student.setCourseName(newCourse);
            }

            System.out.println("Student information updated.");
        } else if (choice.equalsIgnoreCase("D")) {
            students.remove(student);
            System.out.println("Student deleted.");
        } else {
            System.out.println("Invalid choice.");
        }
    }
}
