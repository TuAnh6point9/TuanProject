/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.myproject.week4.short105;

import java.util.Scanner;

/**
 *
 * @author LENOVO
 */
public class Teacher extends Person {
    private int yearInProfession;
    private String contractType;
    private double salaryCoefficient;

    public Teacher() {
        super();
        this.yearInProfession = 0;
        this.contractType = "";
        this.salaryCoefficient = 0.0;
    }
@Override
public void input(Scanner scanner) {
    super.input(scanner);

    while (true) {
        System.out.print("Year in the profession: ");
        if (scanner.hasNextInt()) {
            yearInProfession = scanner.nextInt();
            if (yearInProfession >= 0 && yearInProfession < (java.time.Year.now().getValue() - yearOfBirth)) {
                break;
            }
        } else {
            scanner.next();
        }
        System.out.println("Data input is invalid");
    }

    while (true) {
        System.out.print("Contract type (Long/Short): ");
        contractType = scanner.next();
        if (contractType.equalsIgnoreCase("Long") || contractType.equalsIgnoreCase("Short")) {
            break;
        }
        System.out.println("Data input is invalid");
    }

    while (true) {
        System.out.print("Salary coefficient: ");
        if (scanner.hasNextDouble()) {
            salaryCoefficient = scanner.nextDouble();
            if (salaryCoefficient >= 0) {
                break;
            }
        } else {
            scanner.next();
        }
        System.out.println("Data input is invalid");
    }
}


    @Override
    public void display() {
    super.display();
    System.out.printf(" - %d - %s - %.1f\n", yearInProfession, contractType, salaryCoefficient);
}

    public int getYearInProfession() {
        return yearInProfession;
    }
}