/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.myproject.week4.short105;

import java.util.Scanner;

/**
 *
 * @author LENOVO
 */
public class Student extends Person {
    private int yearOfAdmission;
    private double entranceScore;

    public Student() {
        super();
        this.yearOfAdmission = 0;
        this.entranceScore = 0.0;
    }

    @Override
     public void input(Scanner scanner) {
        super.input(scanner);

        while (true) {
            System.out.print("Year of admission: ");
            if (scanner.hasNextInt()) {
                yearOfAdmission = scanner.nextInt();
                if (yearOfAdmission >= yearOfBirth && yearOfAdmission <= java.time.Year.now().getValue()) {
                    break;
                }
            } else {
                scanner.next();
            }
            System.out.println("Data input is invalid");
        }

        while (true) {
            System.out.print("Entrance English score: ");
            if (scanner.hasNextDouble()) {
                entranceScore = scanner.nextDouble();
                if (entranceScore >= 0 && entranceScore <= 100) {
                    break;
                }
            } else {
                scanner.next();
            }
            System.out.println("Data input is invalid");
        }
    }


    @Override
    public void display() {
        super.display();
        System.out.printf(" - %d - %.1f\n", yearOfAdmission, entranceScore);
    }

    public int getYearOfAdmission() {
        return yearOfAdmission;
    }
}
