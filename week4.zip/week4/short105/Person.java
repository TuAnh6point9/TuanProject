/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.myproject.week4.short105;

/**
 *
 * @author LENOVO
 */
import java.util.Scanner;

public class Person {
    protected String id;
    protected String fullName;
    protected String phoneNumber;
    protected int yearOfBirth;
    protected String major;

    public Person() {
        this.id = "";
        this.fullName = "";
        this.phoneNumber = "";
        this.yearOfBirth = 0;
        this.major = "";
    }

    public void input(Scanner scanner) {
        while (true) {
            System.out.print("ID: ");
            id = scanner.next();
            if (id.matches("\\d{6}")) break;
            System.out.println("Data input is invalid"); 
        }

        scanner.nextLine();
        while (true) {
            System.out.print("Fullname: ");
            fullName = scanner.nextLine();
            if (fullName.matches("[a-zA-Z ]+")) break;
            System.out.println("Data input is invalid");
        }

        while (true) {
            System.out.print("Phone number: ");
            phoneNumber = scanner.next();
            if (phoneNumber.matches("\\d{12}")) break;
              System.out.println("Data input is invalid");
        }

        while (true) {
            System.out.print("Year of birth: ");
            if (scanner.hasNextInt()) {
                yearOfBirth = scanner.nextInt();
                if (yearOfBirth > 1900 && yearOfBirth < 2025) break;
            } else {
                scanner.next();
            }
                System.out.println("Data input is invalid");
        }

        scanner.nextLine(); 
        while (true) {
            System.out.print("Major: ");
            major = scanner.nextLine();
            if (major.length() <= 30) break;
                System.out.println("Data input is invalid");
        }
    }

    public void display() {
    System.out.printf("%s - %s - %s - %d - %s\n", id, fullName, phoneNumber, yearOfBirth, major);
    }
}    