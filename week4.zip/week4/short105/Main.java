/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.myproject.week4.short105;

/**
 *
 * @author LENOVO
 */

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.Comparator;

public class Main {
    private final Scanner scanner = new Scanner(System.in);
    private final List<Teacher> teachers = new ArrayList<>();
    private final List<Student> students = new ArrayList<>();
    private final List<Person> people = new ArrayList<>();

    public static void main(String[] args) {
        Main app = new Main();
        app.run(); 
    }

    private void run() {
        while (true) {
            System.out.println("\n*** Information Management ***");
            System.out.println("1. Teacher");
            System.out.println("2. Student");
            System.out.println("3. Person");
            System.out.println("4. Exit");
            System.out.print("You choose: ");

            if (!scanner.hasNextInt()) {
                System.out.println("Invalid input. Please enter a number.");
                scanner.next();
                continue;
            }

            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1 -> teacherMenu();
                case 2 -> studentMenu();
                case 3 -> personMenu();
                case 4 -> {
                    System.out.println("BYE AND SEE YOU NEXT TIME");
                    return;
                }
                default -> System.out.println("Invalid choice, try again.");
            }
        }
    }

    private void teacherMenu() {
        while (true) {
            System.out.println("\n*** Teacher Management ***");
            System.out.println("1. Input");
            System.out.println("2. Print");
            System.out.println("3. Exit");
            System.out.print("You choose: ");

            if (!scanner.hasNextInt()) {
                System.out.println("Invalid input. Please enter a number.");
                scanner.next();
                continue;
            }

            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1 -> {
                    Teacher teacher = new Teacher();
                    teacher.input(scanner);
                    teachers.add(teacher);
                    people.add(teacher);
                }
                case 2 -> printTeachers();
                case 3 -> { return; }
                default -> System.out.println("Invalid choice, try again.");
            }
        }
    }

    private void studentMenu() {
        while (true) {
            System.out.println("\n*** Student Management ***");
            System.out.println("1. Input");
            System.out.println("2. Print");
            System.out.println("3. Exit");
            System.out.print("You choose: ");

            if (!scanner.hasNextInt()) {
                System.out.println("Invalid input. Please enter a number.");
                scanner.next();
                continue;
            }

            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1 -> {
                    Student student = new Student();
                    student.input(scanner);
                    students.add(student);
                    people.add(student);
                }
                case 2 -> printStudents();
                case 3 -> { return; }
                default -> System.out.println("Invalid choice, try again.");
            }
        }
    }

    private void personMenu() {
        while (true) {
            System.out.println("\n*** Person Management ***");
            System.out.println("1. Search");
            System.out.println("2. Print all");
            System.out.println("3. Exit");
            System.out.print("You choose: ");

            if (!scanner.hasNextInt()) {
                System.out.println("Invalid input. Please enter a number.");
                scanner.next();
                continue;
            }

            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1 -> searchPerson();
                case 2 -> printAllPeople();
                case 3 -> { return; }
                default -> System.out.println("\033[31mInvalid choice, try again.\033[0m");
            }
        }
    }

    private void printTeachers() {
        System.out.println("\n# - ID - Fullname - Phone number - Year of birth - Major - Year in the profession - Contract type - Salary coefficient");
        teachers.sort(Comparator.comparingInt(Teacher::getYearInProfession).reversed());
        int count = 1;
        for (Teacher teacher : teachers) {
            System.out.print(count++ + " - ");
            teacher.display();
        }
    }

    private void printStudents() {
        System.out.println("\n# - ID - Fullname - Phone number - Year of birth - Major - Year of admission - Entrance English score");
        students.sort(Comparator.comparingInt(Student::getYearOfAdmission));
        int count = 1;
        for (Student student : students) {
            System.out.print(count++ + " - ");
            student.display();
        }
    }

    private void searchPerson() {
        System.out.print("Name: ");
        String nameToSearch = scanner.nextLine().trim().toLowerCase();

        boolean found = false;
        System.out.println("Result:");

        for (Person p : people) {
            if (p.fullName.toLowerCase().contains(nameToSearch)) {
                if (!found) {
                    System.out.println("# - ID - Fullname - Phone number - Year of birth - Major");
                }
                System.out.print((people.indexOf(p) + 1) + " - ");
                p.display();
                found = true;
            }
        }

        if (!found) {
            System.out.println("not found");
        }
    }

    private void printAllPeople() {
        System.out.println("\n# - ID - Fullname - Phone number - Year of birth - Major");
        people.sort(Comparator.comparingInt(p -> p.yearOfBirth));
        int count = 1;
        for (Person p : people) {
            System.out.print(count++ + " - ");
            p.display();
        }
    }
}
