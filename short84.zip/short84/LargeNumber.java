/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.myproject.week5.short84;

/**
 *
 * @author LENOVO
 */
import java.util.Scanner;

public class LargeNumber {
    private String num1;
    private String num2;
    
    public void inputNumbers() {
        Scanner scanner = new Scanner(System.in);
        
        System.out.print("Enter the first number: ");
        num1 = scanner.nextLine().trim();
        
        System.out.print("Enter the second number: ");
        num2 = scanner.nextLine().trim();
    }
    
    public String addLargerNumber() {
        StringBuilder result = new StringBuilder();
        int carry = 0, i = num1.length() - 1, j = num2.length() - 1;
        
        while (i >= 0 || j >= 0 || carry != 0) {
            int digit1 = (i >= 0) ? num1.charAt(i--) - '0' : 0;
            int digit2 = (j >= 0) ? num2.charAt(j--) - '0' : 0;
            int sum = digit1 + digit2 + carry;
            
            result.append(sum % 10);
            carry = sum / 10;
        }
        
        return result.reverse().toString();
        }
    
    public String multiplyLargerNumber() {
        int len1 = num1.length(), len2 = num2.length();
        int[] product = new int[len1 + len2];
        
        for (int i = len1 - 1; i >= 0; i--) {
            for (int j = len2 - 1; j >= 0; j--) {
                int mul = (num1.charAt(i) - '0') * (num2.charAt(j) - '0');
                int sum = mul + product[i + j + 1];
                
                product[i + j + 1] = sum % 10;
                product[i + j] += sum /10;
            }
        }
        
        StringBuilder result = new StringBuilder();
        for (int num : product) {
            if (!(result.isEmpty() && num == 0)) {
                result.append(num);
            }
        } 
        
        return result.isEmpty() ? "0" : result.toString();
    }
    
    public void displayResult() {
        System.out.println("Addition result: " + addLargerNumber());
        System.out.println("Multiplication result: " + multiplyLargerNumber());
    }
}
    
