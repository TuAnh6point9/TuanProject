/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.myproject.week5.short84;

/**
 *
 * @author LENOVO
 */
public class Main {
    public static void main(String[] args) {
        LargeNumber calculator = new LargeNumber();
        calculator.inputNumbers();
        calculator.displayResult();
    }
}
