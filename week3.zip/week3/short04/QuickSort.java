/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.myproject.week3.short04;

/**
 *
 * @author LENOVO
 */
import java.util.Scanner;
import java.util.Random;

public class QuickSort {
    
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.println("Enter the number of elements in the array: ");
        int n = scanner.nextInt();
        
        if (n <= 0) {
            System.out.println("Please input a positive integer. ");
            return;
        }
        
        int[] array = generateRandomArray(n);
        
        System.out.println("Unsorted Array: ");
        displayArray(array);
        
        quickSort(array, 0, array.length - 1 );
        
        System.out.println("Sorted Array: ");
        displayArray(array);
    }
    
    private static int[] generateRandomArray(int size) {
        Random random = new Random();
        int[] array = new int[size];
       for (int i = 0; i < size; i++) {
            array[i] = random.nextInt(100); 
        }
        return array;
    }
    
    private static void displayArray(int[] array) {
          System.out.print("[");
        for (int i = 0; i < array.length; i++) {
            System.out.print(array[i]);
            if (i < array.length - 1) {
                System.out.print(", ");
            }
        }
        System.out.println("]");
    }

    
    private static void quickSort(int[]array, int low, int high) {
        if (low < high) {
            int pivotIndex =  partition(array, low, high);
            quickSort(array, low, pivotIndex - 1);
            quickSort(array, pivotIndex + 1, high);
        }
    }  
    
    private static int partition(int[]array, int low, int high) {
        
        int pivot = array[high];
        int i = low - 1; 

        for (int j = low; j < high; j++) {
            if (array[j] <= pivot) {
                i++;
                swap(array, i, j);
            }
        }
        swap(array, i + 1, high);
        return i + 1;
    }
    
    private static void swap(int[]array, int i, int j) {
        int temp = array[i];
        array[i] = array[j];
        array[j] = temp;
    }
}

  