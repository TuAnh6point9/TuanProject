/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.myproject.week3.short04;

/**
 *
 * @author LENOVO
 */
import java.util.Scanner;
import java.util.Random;

public class QuickSort {

    private int[] array;
    private int pivotValue; // Pivot value is private

    public QuickSort(int size) {
        array = generateRandomArray(size);
    }

    public int[] generateRandomArray(int size) {
        Random random = new Random();
        int[] newArray = new int[size];
        for (int i = 0; i < size; i++) {
            newArray[i] = random.nextInt(100); 
        }
        return newArray;
    }

    public void displayArray() {
        System.out.print("[");
        for (int i = 0; i < array.length; i++) {
            System.out.print(array[i]);
            if (i < array.length - 1) {
                System.out.print(", ");
            }
        }
        System.out.println("]");
    }

    public void quickSort(int low, int high) {
        if (low >= high) return; 

        int pivotIndex = partition(low, high);
        
        quickSort(low, pivotIndex - 1);
        quickSort(pivotIndex, high);
    }

    public int partition(int low, int high) {
        pivotValue = array[(low + high) / 2]; 

        int i = low, j = high;

        while (i <= j) {
            while (array[i] < pivotValue) i++;
            while (array[j] > pivotValue) j--;
            if (i <= j) {
                swap(i, j);
                i++;
                j--;
            }
        }
        return i;
    }

    public void swap(int i, int j) {
        int temp = array[i];
        array[i] = array[j];
        array[j] = temp;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.println("Enter the number of elements in the array: ");
        int n = scanner.nextInt();
        
        if (n <= 0) {
            System.out.println("Please input a positive integer.");
            return;
        }

        QuickSort sorter = new QuickSort(n);
        
        System.out.println("Unsorted Array: ");
        sorter.displayArray();
        
        sorter.quickSort(0, n - 1);
        
        System.out.println("Sorted Array: ");
        sorter.displayArray();
    }
}
