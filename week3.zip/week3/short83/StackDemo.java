/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.myproject.week3.short83;

/**
 *
 * @author LENOVO
 */
import java.util.Scanner;
import java.util.Stack;

class MyStack {
    private Stack<Integer> stackValues;

    public MyStack() {
        stackValues = new Stack<>();
    }
    
        public void push(int value) {
            stackValues.push(value);
            System.out.println("Pushed: "+ value);
        }
        
        public void pop() {
            if(!stackValues.isEmpty()) {
            System.out.println("Popped: "+ stackValues.pop());
        } else {
                System.out.println("The stack is empty, cannot pop.");
            }
        }
        
        public void get() {
            if(!stackValues.isEmpty()) {
            System.out.println("Popped: "+ stackValues.peek());
        } else {
                System.out.println("The stack is empty, no top value.");
            }
        }
    }

        public class StackDemo {
            public static void main(String[] args) {
                MyStack stack = new MyStack();
                Scanner scanner = new Scanner(System.in);
                
                while (true) {
                    System.out.println("\nStack Operations");
                    System.out.println("1.Push");
                    System.out.println("2.Pop");
                    System.out.println("3.Get Top Value");
                    System.out.println("4.Exit");
                    System.out.println("Choose an option: ");
                    int choice = scanner.nextInt();
                    
                    switch(choice) {
                        case 1:
                            System.out.println("Enter value to push: ");
                            int value = scanner.nextInt();
                            stack.push(value);
                            break;
                        case 2:
                            stack.pop();
                            break;
                        case 3:
                            stack.get();
                            break;
                        case 4:
                            System.out.println("Exiting.....");
                            scanner.close();
                            return;
                        default:
                            System.out.println("Invalid choice. Try again");
                    }
                }
            }
        }
 
    
   
