/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.myproject.week3.short01;

/**
 *
 * @author LENOVO
 */
import java.util.Scanner;
import java.util.Random;

public class BubbleSort {
    
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.println("=====Bubble Sort Calculator=====");
        System.out.print("Enter number of array: ");
        
        int arraySize;
        
        while (true) {
            try {
                arraySize = Integer.parseInt(scanner.nextLine());
                if (arraySize > 0 ) {
                    break;
                } else {
                    System.out.print("Please input a positive integer. ");
                }
            } catch (NumberFormatException e) {
                System.out.print("Invalid input! Try again. ");
            }
        }
        
        int[]array = generateRandomArray(arraySize);
        
        System.out.print("Unsorted array: ");
        displayArray(array);
        
        bubbleSort(array);
        
        System.out.print("Sorted array: ");
        displayArray(array);
        
        scanner.close();
    }
    
    public static int[] generateRandomArray(int size) {
        Random random = new Random();
        int[] array = new int[size];
        
        for (int i = 0; i < size; i++) {
            array[i] = random.nextInt(10);
        }
        
        return array;
    }
    
    public static void displayArray(int[] array) {
        System.out.print("[");
        for (int i = 0; i < array.length; i++) {
            System.out.print(array[i]);
            if ( i < array.length -1 ) {
                System.out.print(", ");
            }
        }
        
        System.out.println("]");
    }
    
    public static void bubbleSort(int[] array) {
        int n = array.length;
        boolean swapped;
        
        for (int i = 0; i < n -1; i++) {
            swapped = false;
        
        for (int j = 0; j < n -1; j++ ) {
            if (array[j] > array[j + 1]) {
                int temp = array[j];
                array[j] = array[j + 1];
                array[j + 1] = temp;
                
                swapped = true;
            }
        }
        
        if (!swapped) {
            break;
        }
    }
  }
}