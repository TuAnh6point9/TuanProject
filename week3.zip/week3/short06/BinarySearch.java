/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.myproject.week3.short06;

/**
 *
 * @author LENOVO
 */
import java.util.Scanner;
import java.util.Random;
import java.util.Arrays;

public class BinarySearch {
     public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
         System.out.println("Enter number of array: ");
         int n = scanner.nextInt();
         System.out.println("Enter search value: ");
         int m = scanner.nextInt();
         
         int[] arr = new int[n];
         Random random = new Random();
          for (int i = 0; i < n; i++ ) {
                 arr[i] = random.nextInt(n) + 1;
            }
          
            Arrays.sort(arr);
            
         System.out.print("Sorted array:[");
               for (int i = 0; i < arr.length; i++ ) {
                 System.out.print(arr[i]);
                 if ( i < arr.length -1 ) {
                     System.out.print(",");
                }
            }
               System.out.println("]");
               scanner.nextLine();
               
               int index = Arrays.binarySearch(arr, m);
               
               if (index >= 0) {
                   System.out.println("Found "+ m + " at index: " + index);
               } else {
                   System.out.println("Not found in the array");
               }
                 
    }
    
    
}
