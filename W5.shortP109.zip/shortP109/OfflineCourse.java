/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.myproject.week5.shortP109;

/**
 *
 * @author LENOVO
 */


import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;
import java.util.List;

public class OfflineCourse extends Course {
    String begin;
    String end;
    String campus;

    public OfflineCourse() {
        super();
        this.begin = "";
        this.end = "";
        this.campus = "";
    }

    @Override
    public boolean inputAll(Scanner scanner, List<Course> existingCourse) {
        if (!super.inputAll(scanner, existingCourse)) return false;

        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        Date beginDate, endDate;

        while (true) {
            System.out.print("Begin: ");
            this.begin = scanner.nextLine();
            try {
                beginDate = sdf.parse(this.begin);
                break;
            } catch (Exception e) {
                System.out.println("Data input is invalid, use format DD/MM/YYYY");
            }
        }

        while (true) {
            System.out.print("End: ");
            this.end = scanner.nextLine();
            try {
                endDate = sdf.parse(this.end);
                if (beginDate.compareTo(endDate) < 0) break;
                System.out.println("Data input is invalid, end must be after begin");
            } catch (Exception e) {
                System.out.println("Data input is invalid, use format DD/MM/YYYY");
            }
        }

        while (true) {
            System.out.print("Campus: ");
            this.campus = scanner.nextLine();
            if (!this.campus.isEmpty()) break;
            System.out.println("Data input is invalid");
        }
        return true;
    }

    @Override
    public String toString() {
        return super.toString() + "\nBegin: " + begin + "\nEnd: " + end + "\nCampus: " + campus;
    }

    @Override
    public String toSimpleString() {
        return super.toSimpleString() + "-" + begin + "-" + end + "-" + campus;
    }
}