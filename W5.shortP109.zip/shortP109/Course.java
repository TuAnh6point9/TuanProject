/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.myproject.week5.shortP109;

/**
 *
 * @author LENOVO
 */

import java.util.List;
import java.util.Scanner;

public class Course {
    String courseID;
    String courseName;
    int credits;

    public Course() {
        this.courseID = "";
        this.courseName = "";
        this.credits = 0;
    }

    public boolean inputAll(Scanner scanner, List<Course> existingCourses) {
    while (true) {
        System.out.print("Course ID: ");
        this.courseID = scanner.nextLine();
        if (this.courseID.isEmpty()) {
            System.out.println("Data input is invalid");
            continue;
        }
        boolean isUnique = true;
        for (Course c : existingCourses) {
            if (c.getCourseID().equals(this.courseID)) {
                System.out.println("Data input is invalid, ID must be unique");
                isUnique = false;
                break;
            }
        }
        if (isUnique) break; 
    }

        while (true) {
            System.out.print("Course name: ");
            this.courseName = scanner.nextLine();
            if (!this.courseName.isEmpty()) break;
            System.out.println("Data input is invalid");
        }

        while (true) {
            System.out.print("Credits: ");
            try {
                this.credits = scanner.nextInt();
                scanner.nextLine();
                if (this.credits > 0) break;
                System.out.println("Data input is invalid");
            } catch (Exception e) {
                System.out.println("Data input is invalid");
                scanner.nextLine();
            }
        }
        return true;
    }

    public String getCourseID() {
        return courseID;
    }    
    public String getCourseName() {
        return courseName;
    }

    public String toString() {
        return "Course ID: " + courseID + "\nCourse name: " + courseName + "\nCredits: " + credits;
    }

    public String toSimpleString() {
        return courseID + "-" + courseName + "-" + credits;
    }
}