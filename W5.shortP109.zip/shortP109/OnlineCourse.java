/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.myproject.week5.shortP109;

/**
 *
 * @author LENOVO
 */

import java.util.List;
import java.util.Scanner;

public class OnlineCourse extends Course {
    String platform;
    String instructors;
    String note;

    public OnlineCourse() {
        super();
        this.platform = "";
        this.instructors = "";
        this.note = "";
    }

    @Override
    public boolean inputAll(Scanner scanner, List<Course> existingCourse) {
        if (!super.inputAll(scanner, existingCourse)) return false;

        while (true) {
            System.out.print("Platform: ");
            this.platform = scanner.nextLine();
            if (!this.platform.isEmpty()) break;
            System.out.println("Data input is invalid");
        }

        while (true) {
            System.out.print("Instructors: ");
            this.instructors = scanner.nextLine();
            if (!this.instructors.isEmpty()) break;
            System.out.println("Data input is invalid");
        }

        while (true) {
            System.out.print("Note: ");
            this.note = scanner.nextLine();
            if (!this.note.isEmpty()) break;
            System.out.println("Data input is invalid");
        }
        return true;
    }

    @Override
    public String toString() {
        return super.toString() + "\nPlatform: " + platform + "\nInstructors: " + instructors + "\nNote: " + note;
    }

    @Override
    public String toSimpleString() {
        return super.toSimpleString() + "-" + platform + "-" + instructors + "-" + note;
    }
}