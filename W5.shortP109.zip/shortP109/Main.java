/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.myproject.week5.shortP109;

/**
 *
 * @author LENOVO
 */


import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

public class Main {
    private List<Course> courses;
    private Scanner scanner;

    public Main() {
        this.courses = new ArrayList<>();
        this.scanner = new Scanner(System.in);
    }

    public void run() {
        while (true) {
            displayMenu();
            System.out.print("You choose: ");
            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    addCourse();
                    break;
                case 2:
                    updateCourse();
                    break;
                case 3:
                    deleteCourse();
                    break;
                case 4:
                    printCourse();
                    break;
                case 5:
                    searchCourse();
                    break;
                case 6:
                    System.out.println("BYE AND SEE YOU NEXT TIME");
                    scanner.close();
                    return;
                default:
                    System.out.println("Invalid choice! Please try again");
            }
        }
    }

    private void displayMenu() {
        System.out.println("*** Course Management ***");
        System.out.println("1. Add online course/ offline course");
        System.out.println("2. Update course");
        System.out.println("3. Delete course");
        System.out.println("4. Print all / online course / offline course");
        System.out.println("5. Search information base on course name");
        System.out.println("6. Exit");
    }

    public void addCourse() {
        System.out.println("*** Add new course ***");
        Course course;
        while (true) {
            System.out.print("Online (O) or Offline (F): ");
            String type = scanner.nextLine().trim().toUpperCase();
            if (type.equals("O")) {
                System.out.println("Create new online course");
                course = new OnlineCourse();
                break;
            } else if (type.equals("F")) {
                System.out.println("Create new offline course");
                course = new OfflineCourse();
                break;
            } else {
                System.out.println("Data input is invalid");
            }
        }
        
        while (true) {
            if (course.inputAll(scanner, courses)) {
                courses.add(course);
                break;
            }
        }
    }
        

    public void updateCourse() {
        System.out.println("*** Update course ***");
        System.out.print("Course ID: ");
        String courseID = scanner.nextLine();

        Course courseToUpdate = null;
        for (Course course : courses) {
            if (course.courseID.equals(courseID)) {
                courseToUpdate = course;
                break;
            }
        }

        if (courseToUpdate == null) {
            System.out.print("No data found, do you want to find again? (Y/N): ");
            if (scanner.nextLine().trim().toUpperCase().equals("Y")) {
                updateCourse();
            }
            return;
        }

        System.out.println("*** Search results ***");
        System.out.println(courseToUpdate.toString());
        System.out.println("*** Updating ***");
        System.out.println("Note: Enter empty if you don't want to change it.");

        System.out.print("Course ID: ");
        String newID = scanner.nextLine();
        if (!newID.isEmpty()) courseToUpdate.courseID = newID;

        System.out.print("Course name: ");
        String newName = scanner.nextLine();
        if (!newName.isEmpty()) courseToUpdate.courseName = newName;

        System.out.print("Credits: ");
        String newCredits = scanner.nextLine();
        if (!newCredits.isEmpty()) courseToUpdate.credits = Integer.parseInt(newCredits);

        if (courseToUpdate instanceof OnlineCourse online ) {
            System.out.print("Platform: ");
            String newPlatform = scanner.nextLine();
            if (!newPlatform.isEmpty()) online.platform = newPlatform;

            System.out.print("Instructors: ");
            String newInstructors = scanner.nextLine();
            if (!newInstructors.isEmpty()) online.instructors = newInstructors;

            System.out.print("Note: ");
            String newNote = scanner.nextLine();
            if (!newNote.isEmpty()) online.note = newNote;
        } else if (courseToUpdate instanceof OfflineCourse offline ) {
            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
            System.out.print("Begin: ");
           String newBegin = scanner.nextLine();
        if (!newBegin.isEmpty()) {
            try {
                Date beginDate = sdf.parse(newBegin);
                Date currentEndDate = sdf.parse(offline.end); 
                if (beginDate.compareTo(currentEndDate) >= 0) {
                    System.out.println("Data input is invalid, begin must be before end");
                    return;
                }
                offline.begin = newBegin; 
            } catch (Exception e) {
                System.out.println("Data input is invalid, use format DD/MM/YYYY");
                return;
            }
        }
            System.out.print("End: ");
            String newEnd = scanner.nextLine();
            if (!newEnd.isEmpty()) {
                try {
                    Date beginDate = sdf.parse(offline.begin);
                    Date endDate = sdf.parse(newEnd);
                    if (beginDate.compareTo(endDate) >= 0) {
                        System.out.println("Data input is invalid, end must be after begin");
                        return;
                    }
                    offline.end = newEnd;
                } catch (Exception e) {
                    System.out.println("Data input is invalid, use format DD/MM/YYYY");
                    return;
                }
            }

            System.out.print("Campus: ");
            String newCampus = scanner.nextLine();
            if (!newCampus.isEmpty()) offline.campus = newCampus;
        }

        System.out.println("Updated successfully");
    }

    public void deleteCourse() {
        System.out.println("*** Delete course ***");
        System.out.print("Course ID: ");
        String courseID = scanner.nextLine();

        for (int i = 0; i < courses.size(); i++) {
            if (courses.get(i).courseID.equals(courseID)) {
                courses.remove(i);
                System.out.println("Course deleted successfully");
                return;
            }
        }
    }

    public void printCourse() {
        System.out.println("*** Print course ***");
        System.out.print("Do you want to print all (A), online course (O) or offline course (F): ");
        String type = scanner.nextLine().trim().toUpperCase();

        if (type.equals("A")) {
            System.out.println("Course ID-Course name-Credits");
            for (Course course : courses) {
                System.out.println(course.toSimpleString());
            }
        } else if (type.equals("O")) {
            System.out.println("Course ID-Course name-Credits-Platform-Instructors-Note");
            for (Course course : courses) {
                if (course instanceof OnlineCourse) {
                    System.out.println(course.toSimpleString());
                }
            }
        } else if (type.equals("F")) {
            System.out.println("Course ID-Course name-Credits-Begin-End-Campus");
            for (Course course : courses) {
                if (course instanceof OfflineCourse) {
                    System.out.println(course.toSimpleString());
                }
            }
        } else {
            System.out.println("Invalid choice");
        }
    }

    public void searchCourse() {
        System.out.println("*** Searching ***");
        System.out.print("Course ID: ");
        String courseID = scanner.nextLine();

        for (Course course : courses) {
            if (course.courseID.equals(courseID)) {
                System.out.println("*** Search results ***");
                System.out.println(course.toString());
                return;
            }
        }
        System.out.print("No data found, do you want to find again? (Y/N): ");
        if (scanner.nextLine().trim().toUpperCase().equals("Y")) {
            searchCourse();
        }
    }
    
    public static void main(String[] args) {
        Main program = new Main();
        program.run();
    }
}