/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.myproject.week5.shortP107;

/**
 *
 * @author LENOVO
 */
import java.util.Date;
import java.util.List;
import java.util.Scanner;
import java.text.SimpleDateFormat;


public class Reservation {
    private String bookingID;
    private String customerName;
    private String phoneNumber;
    private String roomNumber;
    private String dateTime;
    private FlightInformation flightInformation;

    public Reservation(String bookingID, String customerName, String phoneNumber, String roomNumber, String dateTime, FlightInformation flightInformation) {
        this.bookingID = bookingID;
        this.customerName = customerName;
        this.phoneNumber = phoneNumber;
        this.roomNumber = roomNumber;
        this.dateTime = dateTime;
        this.flightInformation = flightInformation;
    }
    
    public Reservation() {
        this.bookingID = "";
        this.customerName = "";
        this.phoneNumber = "";
        this.roomNumber = "";
        this.dateTime = "";
        this.flightInformation = null;
    }

    public String getBookingID() {
        return bookingID;
    }

    public void setBookingID(String bookingID) {
        this.bookingID = bookingID;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getRoomNumber() {
        return roomNumber;
    }

    public void setRoomNumber(String roomNumber) {
        this.roomNumber = roomNumber;
    }

    public String getDateTime() {
        return dateTime;
    }

    public void setDateTime(String dateTime) {
        this.dateTime = dateTime;
    }

    public FlightInformation getFlightInformation() {
        return flightInformation;
    }

    public void setFlightInformation(FlightInformation flightInformation) {
        this.flightInformation = flightInformation;
    }
    
    
    public boolean inputReservation( Scanner scanner, List<Reservation> existingReservation) {
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        SimpleDateFormat sdfWithTime = new SimpleDateFormat("dd/MM/yyyy HH:mm");
        sdf.setLenient(false);
        sdfWithTime.setLenient(false);
        Date currentDate = new Date();
        
        while (true) {
            System.out.println("ID: ");
            this.bookingID = scanner.nextLine().trim();
            if (!this.bookingID.matches("\\d{6}")) {
                System.out.println("Data input is invalid");
                continue;
            }
            boolean isUnique = true;
            for (Reservation r : existingReservation) {
                if (r.getBookingID().equals(this.bookingID)) {
                    System.out.println("Data input is invalid, ID must be unique");
                    isUnique = false;
                    break;
                }
            } 
               if (isUnique) break;
            }
        
        while (true) {
            System.out.println("Name: ");
            this.customerName = scanner.nextLine().trim();
            if (this.customerName.matches("\\d[a-zA-Z ]+") && !this.customerName.isEmpty())
                break;
            System.out.println("Data input is invalid");
        }
 
        
        while (true) {
            System.out.println("Phone: ");
            this.phoneNumber = scanner.nextLine().trim();
            if (this.phoneNumber.matches("\\d{12}"))
                break;
            System.out.println("Data input is invalid");
        }
        
        while (true) {
            System.out.println("Room Numbers: ");
            this.roomNumber = scanner.nextLine().trim();
            if (this.roomNumber.matches("\\d{4}"))
                break;
            System.out.println("Data input is invalid");
        }
        
        while (true) {
            System.out.println("Booking Date: ");
            this.dateTime = scanner.nextLine().trim();
            try {
                Date bookingDate = sdf.parse(this.dateTime);
                if (bookingDate.after(currentDate)) break;
                System.out.println("Data input is invalid");
            } catch (Exception e) {
                System.out.println("Data input is invalid");
            }
        }
        
        while (true) {
            System.out.println("Need airport pick up? (Y/N): ");
            String needPickup = scanner.nextLine().trim().toUpperCase();
            if (needPickup.equals("Y")) {
                this.flightInformation = new FlightInformation();
                System.out.println("Flight: ");
                this.flightInformation.setFlightNumber(scanner.nextLine().trim());
                System.out.println("Seat: ");
                this.flightInformation.setSeatNumber(scanner.nextLine().trim());
                
                while (true) {
                    System.out.println("TIme Pick Up ");
                    String timePickUp = scanner.nextLine().trim();
                    try {
                        Date pickupDate = sdfWithTime.parse(timePickUp);
                        Date bookingDate = sdf.parse(this.dateTime);
                        if (pickupDate.after(currentDate) && pickupDate.before(bookingDate)) {
                            this.flightInformation.setTimePickUp(timePickUp);
                            break;
                        }
                        System.out.println("Data input is invalid");
                    } catch (Exception e) {
                        System.out.println("Data input is invalid");
                    }
                }
                break;
            } else if (needPickup.equals("N")) {
                this.flightInformation = null;
                break;
            } else {
                System.out.println("Data input is invalid");
        }
    }
        return true;
    }
        

    @Override
    public String toString() {
        String flightInfo = (flightInformation != null) 
                ? " - " + flightInformation.getFlightNumber() + " - " + flightInformation.getSeatNumber()
                + " - " + flightInformation.getTimePickUp() : "";
        return bookingID + " - " + customerName + " - " + phoneNumber + " - " + roomNumber + " - " + dateTime + flightInfo;
         }
            
       }
    
    
    

