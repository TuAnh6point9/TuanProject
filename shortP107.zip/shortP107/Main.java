/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.myproject.week5.shortP107;

/**
 *
 * @author LENOVO
 */

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Main {
    private List<Reservation> reservations;
    private Scanner scanner;

    public Main() {
        this.reservations = new ArrayList<>();
        this.scanner = new Scanner(System.in);
    }

    public void run() {
        while (true) {
            displayMenu();
            System.out.print("You choose: ");
            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    addReservations();
                    break;
                case 2:
                    updateReservation();
                    break;
                case 3:
                    deleteReservation();
                    break;
                case 4:
                    printFlightInformation();
                    break;
                case 5:
                    printAllReservations();
                    break;
                case 6:
                    System.out.println("BYE AND SEE YOU NEXT TIME");
                    return;
                default:
                    System.out.println("Invalid choice! Please try again");
            }
        }
    }

    private void displayMenu() {
        System.out.println("*** Reservation Management ***");
        System.out.println("1. Create new reservation");
        System.out.println("2. Update reservation");
        System.out.println("3. Delete reservation");
        System.out.println("4. Print Flight Information");
        System.out.println("5. Print all");
        System.out.println("6. Exit");
    }

    public void addReservations() {
        System.out.println("*** Create new reservation ***");
        Reservation reservation = new Reservation();
        if (reservation.inputReservation(scanner, reservations)) {
            reservations.add(reservation);
            System.out.println("Information saved successfully.");
        }
    }

    public void updateReservation() {
        System.out.println("*** Update reservation ***");
        System.out.print("ID: ");
        String bookingID = scanner.nextLine().trim();

        Reservation reservationToUpdate = null;
        for (Reservation r : reservations) {
            if (r.getBookingID().equals(bookingID)) {
                reservationToUpdate = r;
                break;
            }
        }

        if (reservationToUpdate == null) {
            System.out.println("No information found");
            System.out.print("You want to find again? (Y/N): ");
            if (scanner.nextLine().trim().toUpperCase().equals("Y")) {
                updateReservation();
            }
            return;
        }

        System.out.println("ID - Name - Phone - RoomNumbers - BookingDate - Flight - Seat - TimePickUp");
        System.out.println(reservationToUpdate.toString());
        System.out.println("If you do not want to change the information, just press enter to skip.");

        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        SimpleDateFormat sdfWithTime = new SimpleDateFormat("dd/MM/yyyy HH:mm");
        Date currentDate = new Date();

        System.out.print("Name: ");
        String newName = scanner.nextLine().trim();
        if (!newName.isEmpty()) {
            if (newName.matches("[a-zA-Z ]+")) {
                reservationToUpdate.setCustomerName(newName);
            } else {
                System.out.println("Data input is invalid");
                return;
            }
        }

        System.out.print("Phone: ");
        String newPhone = scanner.nextLine().trim();
        if (!newPhone.isEmpty()) {
            if (newPhone.matches("\\d{12}")) {
                reservationToUpdate.setPhoneNumber(newPhone);
            } else {
                System.out.println("Data input is invalid");
                return;
            }
        }

        System.out.print("RoomNumbers: ");
        String newRoom = scanner.nextLine().trim();
        if (!newRoom.isEmpty()) {
            if (newRoom.matches("\\d{4}")) {
                reservationToUpdate.setRoomNumber(newRoom);
            } else {
                System.out.println("Data input is invalid");
                return;
            }
        }

        System.out.print("BookingDate: ");
        String newDate = scanner.nextLine().trim();
        if (!newDate.isEmpty()) {
            try {
                Date bookingDate = sdf.parse(newDate);
                if (bookingDate.after(currentDate)) {
                    reservationToUpdate.setDateTime(newDate);
                    if (reservationToUpdate.getFlightInformation() != null) {
                        Date pickupDate = sdfWithTime.parse(reservationToUpdate.getFlightInformation().getTimePickUp());
                        if (pickupDate.after(bookingDate)) {
                            System.out.println("Data input is invalid, timePickUp must be before bookingDate");
                            return;
                        }
                    }
                } else {
                    System.out.println("Data input is invalid");
                    return;
                }
            } catch (Exception e) {
                System.out.println("Data input is invalid");
                return;
            }
        }

        System.out.print("Need airport pick up? (Y/N): ");
        String needPickup = scanner.nextLine().trim().toUpperCase();
        if (!needPickup.isEmpty()) {
            if (needPickup.equals("Y")) {
                FlightInformation flightInfo = reservationToUpdate.getFlightInformation() != null 
                    ? reservationToUpdate.getFlightInformation() : new FlightInformation();
                System.out.print("Flight: ");
                String newFlight = scanner.nextLine().trim();
                if (!newFlight.isEmpty()) flightInfo.setFlightNumber(newFlight);

                System.out.print("Seat: ");
                String newSeat = scanner.nextLine().trim();
                if (!newSeat.isEmpty()) flightInfo.setSeatNumber(newSeat);

                System.out.print("TimePickUp: ");
                String newTimePickUp = scanner.nextLine().trim();
                if (!newTimePickUp.isEmpty()) {
                    try {
                        Date pickupDate = sdfWithTime.parse(newTimePickUp);
                        Date bookingDate = sdf.parse(reservationToUpdate.getDateTime());
                        if (pickupDate.after(currentDate) && pickupDate.before(bookingDate)) {
                            flightInfo.setTimePickUp(newTimePickUp);
                        } else {
                            System.out.println("Data input is invalid");
                            return;
                        }
                    } catch (Exception e) {
                        System.out.println("Data input is invalid");
                        return;
                    }
                }
                reservationToUpdate.setFlightInformation(flightInfo);
            } else if (needPickup.equals("N")) {
                reservationToUpdate.setFlightInformation(null);
            }
        }

        System.out.println("ID - Name - Phone - RoomNumbers - BookingDate - Flight - Seat - TimePickUp");
        System.out.println(reservationToUpdate.toString());
        System.out.println("Information saved successfully.");
    }

    public void deleteReservation() {
        System.out.println("*** Delete reservation ***");
        System.out.print("ID: ");
        String bookingID = scanner.nextLine().trim();

        Reservation reservationToDelete = null;
        for (Reservation r : reservations) {
            if (r.getBookingID().equals(bookingID)) {
                reservationToDelete = r;
                break;
            }
        }

        if (reservationToDelete == null) {
            System.out.println("No information found");
            System.out.print("You want to find again? (Y/N): ");
            if (scanner.nextLine().trim().toUpperCase().equals("Y")) {
                deleteReservation();
            }
            return;
        }

        System.out.println("ID - Name - Phone - RoomNumbers - BookingDate - Flight - Seat - TimePickUp");
        System.out.println(reservationToDelete.toString());
        System.out.print("Are you sure you want to delete this information? (Y/N): ");
        if (scanner.nextLine().trim().toUpperCase().equals("Y")) {
            reservations.remove(reservationToDelete);
            System.out.println("Information deleted successfully.");
        }
    }

    public void printFlightInformation() {
        System.out.println("*** Flight Information ***");
        System.out.println("ID - Name - Phone - Flight - Seat - TimePickUp");
        reservations.stream()
            .filter(r -> r.getFlightInformation() != null)
            .sorted(Comparator.comparing(r -> r.getFlightInformation().getTimePickUp()))
            .forEach(r -> System.out.println(
                r.getBookingID() + " - " + r.getCustomerName() + " - " + r.getPhoneNumber() + " - " +
                r.getFlightInformation().getFlightNumber() + " - " + r.getFlightInformation().getSeatNumber() + " - " +
                r.getFlightInformation().getTimePickUp()
            ));
    }

    public void printAllReservations() {
        System.out.println("*** Reservation Information ***");
        if (reservations.isEmpty()) {
            System.out.println("No information to view");
        } else {
            System.out.println("ID - Name - Phone - RoomNumbers - BookingDate - Flight - Seat - TimePickUp");
            for (Reservation r : reservations) {
                System.out.println(r.toString());
            }
        }
    }

    public static void main(String[] args) {
        Main program = new Main();
        program.run();
    }
}
