/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.myproject.week8.short80;

/**
 *
 * @author LENOVO
 */
public class ConcreteEastAsiaCountry extends EastAsiaCountries {
    public ConcreteEastAsiaCountry(String countryCode, String countryName, float totalArea, String countryTerrain) {
        super(countryCode, countryName, totalArea, countryTerrain);
    }

    
    public void display() {
        System.out.println("Country Code: "+countryCode);
        System.out.println("Country Name: "+countryName);
        System.out.println("Total Area: " + totalArea + " km2");
        System.out.println("Enter country terrain: "+countryTerrain);
    }
}

