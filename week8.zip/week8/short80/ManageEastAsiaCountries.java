/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.myproject.week8.short80;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author LENOVO
 */
public class ManageEastAsiaCountries {
    private List<ConcreteEastAsiaCountry> eacs = new ArrayList<>();
    private static Scanner scanner = new Scanner(System.in);
    
    public void EnterCountryInformation(ConcreteEastAsiaCountry country) {
        eacs.add(country);
        System.out.println("Country information added successfully!\n");    
    }
    
    public void displayCountryInfor() {
        if(eacs.isEmpty()) {
            System.out.println("No country available for display");
        } else {
            for (ConcreteEastAsiaCountry ea : eacs) {
                ea.display();
                System.out.println("------------------------");
            }
        }
    }
    
    public void SearchCountry() {
        System.out.println("Enter Country Name: ");
        String name = scanner.nextLine();
        
        for (ConcreteEastAsiaCountry ea : eacs) {
            if (ea.getCountryName().equalsIgnoreCase(name)) {
                System.out.println("The country is: "+name);
                System.out.println("------------------------");
                ea.display();
            } else {
                System.out.println("That country doesn't exist.");
            }
            return;
        }
    }
    
    public void DisplaySortedCountry() {
        if (eacs.isEmpty()) {
            System.out.println("No contry available");
            return;
        } 
        
        Collections.sort(eacs, Comparator.comparing(ConcreteEastAsiaCountry::getCountryName));
        
        System.out.println("The country sorted by name: ");
        for (ConcreteEastAsiaCountry ea : eacs) {
            ea.display();
            System.out.println("------------------------");
        }
    }
    public void menu() {
        while (true) {
            System.out.println("\n======== Manage Southeast Asian Countries ========");
            System.out.println("1. Enter country information");
            System.out.println("2. Display all countries");
            System.out.println("3. Search for a country by name");
            System.out.println("4. Display countries sorted by name");
            System.out.println("5. Exit");
            System.out.print("Choose an option: ");
            
            int choice;
            try {
                choice = Integer.parseInt(scanner.nextLine());
            } catch (NumberFormatException e) {
                System.out.println("Invalid input! Please enter a number between 1-5.");
                continue;
            }

            switch (choice) {
                case 1:
        System.out.println("Enter country code: ");
        String code = scanner.nextLine();
        System.out.println("Enter country name: ");
        String name = scanner.nextLine();

        float area;
        while (true) {
         try {
             System.out.println("Enter Total Area(km2): ");
             area = Float.parseFloat(scanner.nextLine());
             if (area <= 0) {
                 throw new NumberFormatException();
             }
             break;
        } catch (NumberFormatException e) {
             System.out.print("Invalid input! Total area must be a positive number.");
        }
}
        System.out.println("Enter country terrain: ");
        String terrain = scanner.nextLine();
                    EnterCountryInformation(new ConcreteEastAsiaCountry(code, name, area, terrain));
                    break;
                case 2:
                    displayCountryInfor();
                    break;
                case 3:
                    SearchCountry();
                    break;
                case 4:
                    DisplaySortedCountry();
                    break;
                case 5:
                    System.out.println("Exiting program...");
                    return;
                default:
                    System.out.println("Invalid choice! Please select from 1 to 5.");
            }
        }
    }

    public static void main(String[] args) {
        ManageEastAsiaCountries manager = new ManageEastAsiaCountries();
        manager.menu();
    }
}
    
    
    
    
    
    

