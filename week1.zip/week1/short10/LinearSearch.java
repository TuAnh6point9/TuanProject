/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package week1.short10;

/**
 *
 * @author LENOVO
 */
import java.util.Scanner;
import java.util.Random;

public class LinearSearch {
     private int[] array;
    
    
    public LinearSearch(int n) {
        this.array = new int[n];
    }
    
     void addValue() {
        Random random = new Random();
        for (int i = 0; i < array.length; i++) {
            array[i]= random.nextInt(100);
        }
    }
    public void showValue() {
        System.out.print("The array: [");
        for ( int i = 0; i < array.length; i++) {
            System.out.print(array[i]);
            if ( i < array.length - 1) {
                System.out.print(", ");
            }
        }
        System.out.print("]\n");
        }
    public int searchValue(int value) {
        for ( int i = 0; i < array.length; i++) {
            if (array[i] == value) {
                return i;
            }
        }
        return -1;
    }
}

