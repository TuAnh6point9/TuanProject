/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package week1.short10;

/**
 *
 * @author LENOVO
 */
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter number of array: ");
        int size = scanner.nextInt();

        LinearSearch linearSearch = new LinearSearch(size);

        linearSearch.addValue();

        linearSearch.showValue();

        System.out.print("Enter value search: ");
        int value = scanner.nextInt();

        int index = linearSearch.searchValue(value);
        if (index != -1) {
            System.out.println(value + " found at index: " + index);
        } else {
            System.out.println(value + " not found in the array.");
        }

        scanner.close();
    }
}

