/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.myproject.week1.short50;

/**
 *
 * @author LENOVO
 */
import java.util.ArrayList;
import java.util.List;

public class EquationSolver {

    public List<Float> calculateQuadraticEquation(float a, float b, float c) {
        List<Float> solutions = new ArrayList<>();
        if (a == 0) {
            return solutions; 
        }

        float discriminant = b * b - 4 * a * c;
        if (discriminant > 0) {
            solutions.add((-b + (float) Math.sqrt(discriminant)) / (2 * a));
            solutions.add((-b - (float) Math.sqrt(discriminant)) / (2 * a));
        } else if (discriminant == 0) {
            solutions.add(-b / (2 * a));
        }
        return solutions;
    }

    public void displayNumbers(float... numbers) {
        System.out.println("Odd Numbers:");
        for (float number : numbers) {
            if (isOdd(number)) {
                System.out.print(number + " ");
            }
        }
        System.out.println();

        System.out.println("Even Numbers:");
        for (float number : numbers) {
            if (!isOdd(number)) {
                System.out.print(number + " ");
            }
        }
        System.out.println();

        System.out.println("Perfect Squares:");
        for (float number : numbers) {
            if (isPerfectSquare(number)) {
                System.out.print(number + " ");
            }
        }
        System.out.println();
    }

    private boolean isOdd(float number) {
        return ((int) number) % 2 != 0;
    }

    private boolean isPerfectSquare(float number) {
        if (number < 0) return false;
        int sqrt = (int) Math.sqrt(number);
        return sqrt * sqrt == number;
    }
}    
































