/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.myproject.week1.short50;

/**
 *
 * @author LENOVO
 */
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        EquationSolver solver = new EquationSolver();
        int choice;

        do {
            System.out.println("===== Equation Program =====");
            System.out.println("1. Calculate Superlative Equation");
            System.out.println("2. Calculate Quadratic Equation");
            System.out.println("3. Exit");
            System.out.print("Please choose one option: ");

            try {
                choice = Integer.parseInt(scanner.nextLine());

                switch (choice) {
                    case 1:
                        System.out.println("----- Calculate Equation -----");
                        float a = promptForFloat(scanner, "Enter A: ");
                        float b = promptForFloat(scanner, "Enter B: ");

                        if (a == 0) {
                            System.out.println("No solution (A cannot be 0).");
                        } else {
                            float solution = -b / a;
                            System.out.println("Solution: x = " + solution);
                            solver.displayNumbers(a, b);
                        }
                        break;

                    case 2:
                        System.out.println("----- Calculate Quadratic Equation -----");
                        float aQ = promptForFloat(scanner, "Enter A: ");
                        float bQ = promptForFloat(scanner, "Enter B: ");
                        float cQ = promptForFloat(scanner, "Enter C: ");

                        if (aQ == 0) {
                            System.out.println("This is not a quadratic equation (A cannot be 0).");
                        } else {
                            List<Float> roots = solver.calculateQuadraticEquation(aQ, bQ, cQ);
                            if (roots.isEmpty()) {
                                System.out.println("No solution.");
                            } else {
                                System.out.println("Solutions: " + roots);
                            }
                            solver.displayNumbers(aQ, bQ, cQ);
                        }
                        break;

                    case 3:
                        System.out.println("Exiting program. Goodbye!");
                        return;

                    default:
                        System.out.println("Invalid choice. Please try again.");
                }
            } catch (NumberFormatException e) {
                System.out.println("Invalid choice. Please enter a number between 1 and 3.");
            }
        } while (true);
    }
    private static float promptForFloat(Scanner scanner, String prompt) {
        while (true) {
            System.out.print(prompt);
            try {
                return Float.parseFloat(scanner.nextLine());
            } catch (NumberFormatException e) {
                System.out.println("Please input number");
            }
        }
    }
}
    
    
    
    
    
    
    
    
    
