/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.myproject.week1.short11;

/**
 *
 * @author LENOVO
 */
public class BaseConverter {

    public static String convertBase(String input, int fromBase, int toBase) {
        try {
            int decimalValue = Integer.parseInt(input, fromBase);

            return Integer.toString(decimalValue, toBase).toUpperCase();
        } catch (NumberFormatException e) {
            return "Invalid input for the specified base.";
        }
    }
}