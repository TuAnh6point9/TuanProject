/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.myproject.week1.short11;

/**
 *
 * @author LENOVO
 */
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Welcome to the Base Converter!");

        System.out.println("Enter the source base (2 for Binary, 10 for Decimal, 16 for Hexadecimal):");
        int fromBase = scanner.nextInt();
        scanner.nextLine();

        System.out.println("Enter the number to convert:");
        String input = scanner.nextLine();

        System.out.println("Enter the target base (2 for Binary, 10 for Decimal, 16 for Hexadecimal):");
        int toBase = scanner.nextInt();

        String result = BaseConverter.convertBase(input, fromBase, toBase);
        System.out.println("Converted result: " + result);
    }
}